import os
import io
import json
import pymysql
import bcrypt
import zlib
import struct
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from docx import Document
from openai import OpenAI
import olefile
from pypdf import PdfReader
    

# .env 경로 명시적 설정
load_dotenv(dotenv_path=Path('C:/GG/Python/.env'))

app = FastAPI()

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# DB 연결 함수
def get_db_connection():
    return pymysql.connect(
        host=os.getenv("DB_HOST"),
        port=int(os.getenv("DB_PORT", 3307)),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASS"),
        database=os.getenv("DB_NAME"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor
    )

# --- 모델 및 파싱 로직 ---

class SignUpModel(BaseModel):
    userName: str = "사용자"
    userId: str
    userPw: str
    userPhone: str
    userEmail: str

class LoginModel(BaseModel):
    userId: str
    userPw: str

# HWP 5.0 바이너리 데이터에서 압축을 풀고 순수 텍스트만 정밀 추출하는 함수
def extract_text_from_hwp(file_bytes):
    try:
        f = olefile.OleFileIO(io.BytesIO(file_bytes))
        dirs = f.listdir()
        
        # 1. HWP 파일 버전 및 압축 여부 확인 정보가 담긴 FileHeader 체크
        header_data = f.openstream("FileHeader").read()
        is_compressed = (header_data[36] & 1) == 1
        
        # 2. 실제 본문 텍스트가 담긴 BodyText 섹션들 수집 후 정렬
        bodytext_sections = [d for d in dirs if d[0] == 'BodyText']
        bodytext_sections.sort(key=lambda x: x[1] if len(x) > 1 else "")
        
        extracted_texts = []
        
        for section in bodytext_sections:
            data = f.openstream(section).read()
            
            # 압축이 되어 있다면 zlib으로 압축 해제
            if is_compressed:
                try:
                    data = zlib.decompress(data, -15)
                except zlib.error:
                    data = zlib.decompress(data)
            
            # 바이너리 스트림에서 텍스트 레코드(67번 HWPTAG_PARA_TEXT)만 발라내기
            offset = 0
            while offset < len(data):
                if offset + 4 > len(data):
                    break
                
                header = struct.unpack_into("<I", data, offset)[0]
                record_type = header & 0x3FF
                record_length = (header >> 20) & 0xFFF
                
                offset += 4
                if record_length == 0xFFF:
                    if offset + 4 > len(data): break
                    record_length = struct.unpack_into("<I", data, offset)[0]
                    offset += 4
                
                # 67번 레코드가 순수 문단 텍스트 정보입니다.
                if record_type == 67:
                    text_bytes = data[offset : offset + record_length]
                    paragraph_text = text_bytes.decode('utf-16-le', errors='ignore')
                    
                    # 불필요한 제어 문자 청소
                    clean_text = "".join([c for c in paragraph_text if ord(c) >= 0x0020 or c in ['\n', '\t', '\r']])
                    if clean_text.strip():
                        extracted_texts.append(clean_text.strip())
                
                offset += record_length
                
        return "\n".join(extracted_texts)
        
    except Exception as e:
        print(f"[HWP 정밀 파싱 에러] 원인: {e}")
        return ""

# 이력서 파싱을 OpenAI에서 로컬 Ollama로 변경
def parse_document_via_ai(text_content):
    try:
        ollama_client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama"
        )
        
        system_prompt = (
            "당신은 다양한 양식의 이력서와 자기소개서를 전문적으로 분석하여 핵심 정보를 추출하는 '인공지능 인사 분석 엔진'입니다.\n"
            "제시된 이력서 본문의 흐름과 문맥을 파악하여, 아래 4가지 표준 카테고리에 가장 알맞은 내용을 유연하게 분류하고 요약하여 완벽한 JSON 오브젝트로만 응답하세요.\n\n"
            
            "[분석 및 분류 지침]\n"
            "1. 'skills_and_specs':\n"
            "   - 보유 기술, 프로그래밍 언어, 자격증, 학력, 다룰 줄 아는 툴(Tool), 다수의 수상 경력 등 지원자의 '하드 스킬(적격 요건)'에 해당하는 모든 요소를 찾아 통합 요약하세요.\n"
            "2. 'experience_projects':\n"
            "   - 회사 경력, 인턴, 개인/팀 프로젝트, 대외 활동, 동아리 활동, 캡스톤 디자인 등 무언가를 개발하거나 수행한 '경험 및 성과'를 모두 찾아 요약하세요.\n"
            "3. 'motivation':\n"
            "   - 지원 동기, 입사 후 포부, 왜 이 직무를 선택했는지 등 '의지나 목적'이 드러난 내용을 찾아 요약하세요.\n"
            "4. 'personality':\n"
            "   - 성격의 장단점, 가치관, 협업 스타일 등 지원자의 '소프트 스킬'을 분석하여 요약하세요.\n\n"
            
            "[⚠️ 중요 규칙]\n"
            "- 답변은 반드시 JSON 데이터 그 자체만 출력해야 하며, 앞뒤로 마크다운 기호(```json 등)나 인사말을 절대 포함하지 마십시오."
        )

        response = ollama_client.chat.completions.create(
            model="gemma2:9b", 
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text_content}
            ],
            temperature=0.1
        )
        
        parsed_json = json.loads(response.choices[0].message.content)
        
        default_result = {"skills_and_specs": "", "experience_projects": "", "motivation": "", "personality": ""}
        for key in default_result.keys():
            if key in parsed_json:
                default_result[key] = parsed_json[key]
                
        return default_result
        
    except Exception as e:
        print(f"로컬 AI 파싱 에러: {e}")
        return {"skills_and_specs": "", "experience_projects": "", "motivation": "", "personality": ""}

# --- API 엔드포인트 ---

@app.post("/signup")
def signup(data: SignUpModel):
    conn = get_db_connection()
    try:
        password_bytes = data.userPw.encode('utf-8')
        hashed_password = bcrypt.hashpw(password_bytes, bcrypt.gensalt()).decode('utf-8')
        with conn.cursor() as cursor:
            sql = "INSERT INTO users (user_name, user_id, user_pw, user_phone, user_email) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(sql, (data.userName, data.userId, hashed_password, data.userPhone, data.userEmail))
        conn.commit()
        return {"status": "success", "message": "회원가입 성공!"}
    except Exception as e:
        return {"status": "fail", "message": str(e)}
    finally:
        conn.close()

@app.post("/login")
def login(data: LoginModel):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT user_id, user_pw, user_name FROM users WHERE user_id = %s"
            cursor.execute(sql, (data.userId,))
            user = cursor.fetchone()
            if not user or not bcrypt.checkpw(data.userPw.encode('utf-8'), user['user_pw'].encode('utf-8')):
                return {"status": "fail", "message": "아이디 또는 비밀번호가 잘못되었습니다."}
            return {"status": "success", "user_name": user['user_name'], "user_id": user['user_id']}
    finally:
        conn.close()

# 🛠️ [수정완료] 실제 DB 구조(company, job) 컬럼과 일치하도록 매핑 수정
@app.post("/upload-resume")
async def upload_resume(
    file: UploadFile = File(...),
    user_id: str = Form(...),      
    companyName: str = Form("지정되지 않음"),  
    jobTitle: str = Form("지정되지 않음")      
):
    try:
        # 1. 파일 바이너리 전체 읽기 및 이름 소문자 변환
        contents = await file.read()
        filename_lower = file.filename.lower()
        resume_text = ""

        print(f"[{user_id}] 이력서 파일 업로드 요청 시작... 파일명: {file.filename}")

        # 2. 확장자별 분기 처리 (.docx / .pdf / .hwp)
        if filename_lower.endswith('.docx'):
            doc = Document(io.BytesIO(contents))
            for para in doc.paragraphs:
                if para.text.strip():
                    resume_text += para.text + "\n"

        elif filename_lower.endswith('.pdf'):
            reader = PdfReader(io.BytesIO(contents))
            pdf_text = []
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    pdf_text.append(text)
            resume_text = "\n".join(pdf_text)

        elif filename_lower.endswith('.hwp'):
            resume_text = extract_text_from_hwp(contents)

        else:
            return {
                "status": "fail", 
                "message": "지원하지 않는 파일 형식입니다. (.docx, .pdf, .hwp 파일만 가능합니다.)"
            }
                
        # 3. 텍스트 추출 검증 및 예외 방어
        if not resume_text.strip():
            return {"status": "fail", "message": "이력서에서 텍스트를 추출할 수 없거나 빈 문서입니다."}

        # 4. 실제 이력서의 지나치게 긴 텍스트로 인한 뻗음 방지
        if len(resume_text) > 4000:
            print(f"[경고] 이력서 텍스트가 너무 길어 핵심 상위 4000자만 추출합니다. (총 {len(resume_text)}자)")
            resume_text = resume_text[:4000]

        # 5. AI에게 정제 요청을 위한 프롬프트 작성
        system_prompt = (
            "당신은 프로페셔널한 채용 담당자이자 데이터 정제 AI입니다.\n"
            "제공된 지원자의 이력서 텍스트를 분석하여, 다음 JSON 포맷으로만 응답하세요.\n"
            "절대 JSON 이외의 설명이나 인사말을 포함하지 마세요.\n\n"
            "{\n"
            "  \"name\": \"지원자 이름 (찾을 수 없으면 '지원자')\",\n"
            "  \"skills\": [\"보유 기술 리스트 3~5개\"],\n"
            "  \"experience\": \"주요 경력 또는 프로젝트 요약 (2~3줄)\"\n"
            "}"
        )
        
        # 로컬 Ollama 클라이언트 명시적 선언
        ollama_client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama"
        )

        # 6. Ollama API 호출
        response = ollama_client.chat.completions.create(
            model="gemma2:9b",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"이력서 내용:\n{resume_text}"}
            ],
            temperature=0.3
        )

        print("--- AI 원본 응답 로그 ---")
        print(response)
        print("------------------------")

        ai_content = response.choices[0].message.content.strip()

        if ai_content.startswith("```"):
            ai_content = ai_content.replace("```json", "").replace("```", "").strip()

        # 7. JSON 파싱
        try:
            parsed_data = json.loads(ai_content)
        except json.JSONDecodeError:
            print(f"[JSON 파싱 실패 원본]: {ai_content}")
            return {"status": "fail", "message": "AI의 응답을 JSON 구조로 파싱하는 데 실패했습니다. 다시 시도해 주세요."}

        # 🗄️ [수정완료] DB 컬럼 구조에 맞게 company_name -> company, job_title -> job으로 매핑 변경
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                sql = """
                    INSERT INTO user_resumes (user_id, file_name, raw_text, company, job) 
                    VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(sql, (
                    user_id,
                    file.filename,
                    resume_text,      # 추출된 순수 원본 텍스트 전체
                    companyName,      # 프론트의 companyName 데이터 맵핑
                    jobTitle          # 프론트의 jobTitle 데이터 맵핑
                ))
            conn.commit()
            print(f"[{user_id}] 데이터베이스(user_resumes) 이력서 적재 완료: {file.filename}")
        except Exception as db_err:
            if conn: conn.rollback()
            print(f"[이력서 DB 적재 에러] 원인: {db_err}")
            return {"status": "fail", "message": f"이력서 해석은 완료되었으나 데이터베이스 저장에 실패했습니다: {str(db_err)}"}
        finally:
            conn.close()

        # 8. 리스트 갱신을 위해 최종 성공 데이터 반환
        return {
            "status": "success",
            "data": {
                "name": parsed_data.get("name", "지원자"),
                "skills": parsed_data.get("skills", []),
                "experience": parsed_data.get("experience", "")
            }
        }

    except Exception as e:
        print(f"[이력서 파싱 최종 에러 로그]: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"status": "fail", "message": f"이력서 처리 중 서버 오류 발생: {str(e)}"}

@app.post("/check-id")
def check_id(data: dict):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT user_id FROM users WHERE user_id = %s"
            cursor.execute(sql, (data.get("userId"),))
            result = cursor.fetchone()
        return {"status": "fail" if result else "success"}
    finally:
        conn.close()

@app.get("/get-resumes")
def get_resumes(user_id: str):
    conn = get_db_connection()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            sql = "SELECT resume_id, file_name, LEFT(raw_text, 20) as preview FROM user_resumes WHERE user_id = %s ORDER BY resume_id DESC"
            cursor.execute(sql, (user_id,))
            return {"status": "success", "data": cursor.fetchall()}
    finally:
        conn.close()

class DeleteResumeModel(BaseModel):
    user_id: str
    resume_id: int

@app.post("/delete-resume")
def delete_resume(data: DeleteResumeModel):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "DELETE FROM user_resumes WHERE resume_id = %s AND user_id = %s"
            affected_rows = cursor.execute(sql, (data.resume_id, data.user_id))
            
        if affected_rows == 0:
            return {"status": "fail", "message": "삭제할 이력서가 존재하지 않거나 권한이 없습니다."}
            
        conn.commit()
        return {"status": "success", "message": "이력서가 성공적으로 삭제되었습니다."}
    except Exception as e:
        if conn: conn.rollback()
        print(f"이력서 삭제 에러: {e}")
        return {"status": "fail", "message": f"서버 내부 에러: {str(e)}"}
    finally:
        conn.close()        

# --- 면접 및 LLM 관련 Pydantic 모델 정의 ---
class StartInterviewModel(BaseModel):
    user_id: str
    company: str
    job: str
    style: str
    resume_id: str

class NextQuestionModel(BaseModel):
    messages: list

# 면접 시작 및 초기 프롬프트/인사말 생성 API
@app.post("/start-interview")
def start_interview(data: StartInterviewModel):
    conn = get_db_connection()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            sql = "SELECT raw_text FROM user_resumes WHERE resume_id = %s AND user_id = %s"
            cursor.execute(sql, (data.resume_id, data.user_id))
            resume = cursor.fetchone()
        
        doc_text = resume['raw_text'] if resume else "등록된 이력서 정보가 없습니다."

        system_prompt = f"""
        너는 {data.company}의 {data.job} 채용을 담당하는 베테랑 AI 면접관이다.
        현재 면접 대상자의 이력서 및 자기소개서 데이터를 바탕으로 1:1 면접을 진행하고 있다.
        
        [⚠️ 중요 규칙 - 반드시 준수할 것]
        1. 질문은 무조건 한 번에 '딱 한 개'씩만 던져라.
        2. 실제 면접관처럼 일관되게 자연스럽고 격식 있는 한국어 경어체를 사용해라.
        3. 모든 답변은 반드시 100% 한국어여야만 한다. 절대 영어로 답변하지 마라.
        4. 지원자의 답변 내용을 바탕으로 본격적인 {data.style} 성향에 맞춘 날카롭거나 공감어린 다음 면접 꼬리 질문을 한국어로 전개해라.
        5. 지원자가 오타나 잘못된 말을 하면 한번 더 설명 해 달라 요구한다.
        6. ★ 만약 지원자의 가장 최신 답변에 비속어, 욕설, 음란어, 인신공격 등 면접과 무관하고 부적절한 단어나 내용이 '단 하나라도' 포함되어 있다면, 아래 [면접 진행 지침]을 완전히 무시하고 즉시 다음 형태처럼 매우 불쾌한 어조로 답변한 뒤 면접 종료를 선언하십시오.
        7. 지원자의 질문에 꼬리를 무는 질문을 하지만 변칙적으로 이력서의 있는 내용을 기반으로 질문을 한다. 
        예시: '방금 하신 말씀은 매우 부적절한 언행입니다. 더 이상 면접을 진행할 수 없다고 판단되므로 즉시 면접을 종료하겠습니다.'
        [지원자 서류 본문 데이터]
        {doc_text}
        """

        if "압박" in data.style:
            style_intro = f"안녕하십니까. {data.company}의 {data.job} 직무 면접을 맡은 면접관입니다. 바로 긴장감 있게 진행해 보죠."
        elif "부드러운" in data.style:
            style_intro = f"안녕하세요! 오늘 {data.company}의 {data.job} 직무 면접을 진행하게 되어 반갑습니다. 편안한 마음으로 임해주세요."
        else:
            style_intro = f"반갑습니다. {data.company}의 {data.job} 직무 채용 면접관입니다. 대답의 논리성과 사실 관계를 중심으로 평가하겠습니다."

        initial_q = f"{style_intro}\n\n먼저 가볍게 **1분 자기소개**부터 부탁드립니다."

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "assistant", "content": initial_q}
        ]

        return {"status": "success", "messages": messages}
    
    except Exception as e:
        print(f"면접 세션 생성 중 예외 발생: {str(e)}")
        return {"status": "fail", "message": f"서버 에러: {str(e)}"}
    finally:
        conn.close()

# 실시간 로컬 Ollama API 호출 및 다음 질문 생성 API
@app.post("/get-next-question")
def get_next_question(data: NextQuestionModel):
    try:
        ollama_client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="gemma2"
        )
        
        response = ollama_client.chat.completions.create(
            model="gemma2:9b",
            messages=data.messages,
            temperature=0.5
        )
        
        if hasattr(response, "choices") and len(response.choices) > 0:
            next_q = response.choices[0].message.content
            return {"status": "success", "next_question": next_q}
        
        return {"status": "fail", "message": "AI 면접관의 응답 형식이 올바르지 않습니다."}
        
    except Exception as e:
        print(f"Ollama 연동 에러: {e}")
        return {"status": "fail", "message": f"AI 면접관 통신 장애: {str(e)}"}
    
# 면접 종료 및 전체 대화 분석 피드백 리포트 생성 & DB 적재 API
@app.post("/end-interview")
def end_interview(data: dict):
    conn = None
    try:
        messages_list = data.get("interview_messages") or data.get("messages") or data.get("chatHistory")
        
        user_id = data.get("user_id")
        company_name = data.get("company_name") or data.get("company", "지정되지 않음")
        job_title = data.get("job_title") or data.get("job", "지정되지 않음")

        if not messages_list or not isinstance(messages_list, list):
            print(f"받은 데이터 구조: {data}")
            return {"status": "fail", "message": "대화 기록 배열(list)을 찾을 수 없습니다."}

        if not user_id:
            return {"status": "fail", "message": "사용자 ID(user_id)가 누락되었습니다."}

        conversation_log = ""
        for msg in messages_list:
            if msg.get("role") == "assistant":
                conversation_log += f"면접관: {msg.get('content')}\n"
            elif msg.get("role") == "user":
                conversation_log += f"지원자: {msg.get('content')}\n"

        if not conversation_log.strip():
            return {"status": "fail", "message": "분석할 면접 대화 기록이 존재하지 않습니다."}

        ollama_client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama"
        )
        
        system_feedback_prompt = (
            "당신은 10년 차 베테랑 채용 팀장이자 기업 면접관입니다. 지원자의 면접 대화록을 심층 분석하여 다음 5가지 항목을 포함한 JSON으로 응답하세요.\n\n"
            "1. total_score (0~100점): 답변의 논리성, 직무 연관성, 태도를 종합적으로 평가한 정수 점수.\n"
            "2. grade (S/A/B/C/D): 점수에 따른 합격 가능성 등급.\n"
            "3. strengths: 지원자가 대화 중 보여준 긍정적인 역량 2가지 이상을 구체적 근거와 함께 서술.\n"
            "4. weaknesses: 답변의 논리적 허점, 부족한 수치적 근거, 모호한 표현 등 보완이 필요한 점 2가지 이상을 구체적 예시와 함께 서술.\n"
            "5. coaching: 면접관이 기대했던 수준 높은 모범 답안의 구조와 핵심 내용을 정리한 코칭 가이드.\n\n"
            "⚠️ 필수 작성 규칙:\n"
            "- 모든 분석은 200자 이상의 풍성한 한글 문장으로 정성스럽게 작성할 것.\n"
            "- 단순한 요약이 아니라, 왜 그렇게 평가했는지 '이유'를 명확히 제시할 것.\n"
            "- JSON 데이터 외에는 어떤 서론, 결론, 마크다운 기호도 포함하지 말고 오직 JSON만 출력할 것.\n"
            "- 피드백은 100% 전문적인 한글 경어체로 작성할 것."
        )

        response = ollama_client.chat.completions.create(
            model="gemma2:9b",
            response_format={ "type": "json_object" },
            messages=[
                {"role": "system", "content": system_feedback_prompt},
                {"role": "user", "content": f"이하 면접 대화 기록을 분석하여 리포트를 작성해라:\n{conversation_log}"}
            ],
            temperature=0.3
        )
        
        if hasattr(response, "choices") and len(response.choices) > 0:
            feedback_json = json.loads(response.choices[0].message.content)
            
            try:
                total_score = int(feedback_json.get("total_score", 0))
            except:
                total_score = 0
                
            grade = str(feedback_json.get("grade", "-"))
            strengths = str(feedback_json.get("strengths", ""))
            weaknesses = str(feedback_json.get("weaknesses", ""))
            coaching = str(feedback_json.get("coaching", ""))

            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    INSERT INTO interview_reports 
                    (user_id, company_name, job_title, total_score, grade, strengths, weaknesses, coaching)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, (
                    user_id,
                    company_name,
                    job_title,
                    total_score,
                    grade,
                    strengths,
                    weaknesses,
                    coaching
                ))
                generated_id = cursor.lastrowid
            conn.commit()

            full_report = {
                "report_id": generated_id,
                "company_name": company_name,
                "job_title": job_title,
                "total_score": total_score,
                "grade": grade,
                "strengths": strengths,
                "weaknesses": weaknesses,
                "coaching": coaching
            }

            return {"status": "success", "report": full_report}
            
        return {"status": "fail", "message": "AI 면접관의 피드백 응답 형식이 올바르지 않습니다."}
        
    except Exception as e:
        if conn: conn.rollback()
        print(f"[Ollama Feedback Error] 상세 원인: {e}")
        return {"status": "fail", "message": f"서버 내부 에러: {str(e)}"}
    finally:
        if conn: conn.close()

@app.get("/get-interview-history")
def get_interview_history(user_id: str):
    conn = get_db_connection()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            sql = """SELECT report_id, company_name, job_title, total_score, grade, 
                            strengths, weaknesses, coaching, created_at 
                     FROM interview_reports WHERE user_id = %s ORDER BY created_at DESC"""
            cursor.execute(sql, (user_id,))
            result = cursor.fetchall()
            return {"status": "success", "data": result}
    except Exception as e:
        print(f"이력 조회 에러: {e}")
        return {"status": "fail", "message": str(e)}
    finally:
        conn.close()